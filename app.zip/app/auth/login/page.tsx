"use client";

import React from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";

export default function LoginPage() {
  const t = useTranslations();
  const formSchema = z.object({
    email: z
      .string()
      .email({ message: t("Please enter a valid email address") }),
    password: z
      .string()
      .min(6, { message: t("Password must be at least 6 characters") }),
  });

  type FormValues = z.infer<typeof formSchema>;

  const { userLogin, isLoading, user } = useAuth();
  const navigate = useRouter();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  async function onSubmit(data: FormValues) {
    try {
      await userLogin(data.email, data.password);
      navigate.push("/admin");
    } catch (error) {
      // Error is handled by the API interceptor
      console.error("Login failed:", error);
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-purple-700 to-blue-900 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold">{t("Login")}</CardTitle>
          <CardDescription>
            {t("Enter your credentials to access your account")}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t("Email")}</FormLabel>
                    <FormControl>
                      <Input placeholder="your.email@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t("Password")}</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="******" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? t("Logging in") + "..." : t("Login")}
              </Button>
            </form>
          </Form>
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          {/* <div className="text-sm text-center">
            Don{"'"}t have an account?{" "}
            <Link href="/auth/register" className="underline text-primary">
              Register
            </Link>
          </div> */}
          <Link href="/" className="w-full">
            <Button variant="outline" className="w-full">
              {t("Back to Home")}
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  );
}
