3- update transactions
4- update print set the branch details
6- update pos :all the needed info !!!!!!!!!!!!!
# Current
