module.exports = {
  i18n: {
    locales: ["en", "ar"],
    defaultLocale: "ar",
  },
  reloadOnPrerender: process.env.NODE_ENV === "development",
};
