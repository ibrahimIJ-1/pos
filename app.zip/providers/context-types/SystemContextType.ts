
export interface SystemContextType {
  storeCurrency:string;
  storeNearestAmount:number;
}
